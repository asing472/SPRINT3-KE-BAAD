﻿//Created by Akash Kumar Singh

using Pecunia.Entities;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;

namespace Pecunia.Contracts.DALContracts
{
    public abstract class RegularAccountDALBase
    {
        //Collection of Regular Accounts
        public static List<GetRegularAccountByAccountNo_Result> regularAccountList = new List<GetRegularAccountByAccountNo_Result>();
       
        //Method for CRUD operations
        public abstract bool CreateAccountDAL(RegularAccount newAccount);
        public abstract List<GetRegularAccountByAccountNo_Result> GetAllAccountsDAL();
        public abstract GetRegularAccountByAccountNo_Result GetAccountByAccountNoDAL(string searchAccountNo);
        public abstract List<GetRegularAccountsByCustomerID_Result> GetAccountsByCustomerIDDAL(Guid searchCustomerID);
        public abstract List<GetRegularAccountsByAccountType_Result> GetAccountsByTypeDAL(string searchAccountType);
        public abstract List<GetRegularAccountsByBranch_Result> GetAccountsByBranchDAL(string searchBranch);
        public abstract List<GetRegularAccountsByAccountOpeningDate_Result> GetAccountsByAccountOpeningDateDAL(DateTime startDate, DateTime endDate);
        public abstract double GetBalanceDAL(string accountNumber);
        public abstract bool UpdateBalanceDAL(string accountNumber, double balance);
        public abstract bool UpdateBranchDAL(string accountNumber, string Branch);
        public abstract bool UpdateAccountTypeDAL(string accountNumber, string accType);
        public abstract bool DeleteAccountDAL(string deleteAccountNo);


        /// <summary>
        /// Static Constructor.
        /// </summary>
        static RegularAccountDALBase()
        {
           
        }
    }
}
