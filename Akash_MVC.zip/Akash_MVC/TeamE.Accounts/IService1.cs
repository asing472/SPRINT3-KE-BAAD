﻿//Created by Akash Kumar Singh

using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace TeamE.Accounts
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IService1" in both code and config file together.
    [ServiceContract]
    public interface IService1
    {

        [OperationContract]
        List<RegularAccountDataContract> GetAllAccountsDAL();

    }


    // Use a data contract as illustrated in the sample below to add composite types to service operations.
    [DataContract]
    public class RegularAccountDataContract
    {
        [DataMember]
        public System.Guid AccountID { get; set; }


        [DataMember]
        public System.Guid CustomerID { get; set; }

        [DataMember]
        public string CustomerNumber { get; set; }

     
        [DataMember]
        public string CustomerName { get; set; }

        [DataMember]
        public string AccountNo { get; set; }

        [DataMember]
        public decimal CurrentBalance { get; set; }

        [DataMember]
        public string AccountType { get; set; }


        [DataMember]
        public string Branch { get; set; }


        [DataMember]
        public string Status { get; set; }

        [DataMember]
        public decimal MinimumBalance { get; set; }

        [DataMember]
        public decimal InterestRate { get; set; }


        [DataMember]
        public DateTime CreationDateTime { get; set; }

        [DataMember]
        public DateTime LastModifiedDateTime { get; set; }

    }
}
