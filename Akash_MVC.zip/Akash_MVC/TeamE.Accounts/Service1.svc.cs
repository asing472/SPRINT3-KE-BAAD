﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;



namespace TeamE.Accounts
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select Service1.svc or Service1.svc.cs at the Solution Explorer and start debugging.
    public class Service1 : IService1
    {
        public List<RegularAccountDataContract> GetAllAccountsDAL()
        {
            //Create factory
            DbProviderFactory factory = DbProviderFactories.GetFactory(System.Configuration.ConfigurationManager.ConnectionStrings["PecuniaConnectionString"].ProviderName);

            //Create connection
            DbConnection connection = factory.CreateConnection();
            connection.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["PecuniaConnectionString"].ConnectionString;

            //Create command
            DbCommand command = connection.CreateCommand();
            command.CommandText = "TeamE.GetAllRegularAccounts";
            command.Connection = connection;
            command.CommandType = System.Data.CommandType.StoredProcedure;

            //Create adapter
            DbDataAdapter adapter = factory.CreateDataAdapter();
            adapter.SelectCommand = command;

            //Create dataset
            DataSet ds = new DataSet();

            //Execute
            adapter.Fill(ds);

            //Convert datatable to collection
            List<RegularAccountDataContract> Account = ds.Tables[0]
                .AsEnumerable()
                .Select(p => new RegularAccountDataContract()
                {
                    AccountID = p.Field<Guid>("AccountID"),
                    CustomerID = p.Field<Guid>("CustomerID"),
                    CustomerNumber = p.Field<string>("CustomerNumber"),
                    CustomerName = p.Field<string>("CustomerName"),
                    AccountNo = p.Field<string>("AccountNo"),
                    CurrentBalance = p.Field<decimal>("CurrentBalance"),
                    AccountType = p.Field<string>("AccountType"),
                    Branch = p.Field<string>("Branch"),
                    Status = p.Field<string>("Status"),
                    MinimumBalance = p.Field<decimal>("MinimumBalance"),
                    InterestRate = p.Field<decimal>("InterestRate"),
                    CreationDateTime = p.Field<DateTime>("CreationDateTime"),
                    LastModifiedDateTime = p.Field<DateTime>("LastModifiedDateTime")
                })
                .ToList();

            return Account;
        }
    }
}
