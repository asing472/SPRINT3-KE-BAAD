﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace Pecunia.Mvc.Models
{
    public class RegularAccountViewModel
    {
        public Guid AccountID { get; set; }

        [Required(ErrorMessage = "Enter account number")]
        [RegularExpression("^(?<tail>\\d{10})$", ErrorMessage = "Account number should contain 10 digits")]
        public string AccountNo { get; set; }

        public string CustomerName { get; set; }

        [Required(ErrorMessage = "Customer number can´t be blank")]
        [RegularExpression("^(?<tail>\\d{6})$", ErrorMessage = "Customer number should contain 6 digits")]
        public string CustomerNumber { get; set; }

        [Required(ErrorMessage = "Choose a type of account")]
        public string AccountType { get; set; }

        [Required(ErrorMessage = "Select a home branch")]
        public string Branch { get; set; }
 

        [Required(ErrorMessage = "Minimum balance can´t be blank")]
        [RegularExpression("^[+]?([0-9]+(?:[.][0-9]*)?|.[0-9]+)$", ErrorMessage = "Minimum balance should be greater than 0")]
        [Range(0, 5000, ErrorMessage = "Please provide a valid minimum balance range")]
        public decimal? MinimumBalance { get; set; }

        [Required(ErrorMessage = "Interest rate can´t be blank")]
        [RegularExpression("^[+]?([0-9]+(?:[.][0-9]*)?|.[0-9]+)$", ErrorMessage = "Interest rate should be greater than 0")]
        [Range(0, 100, ErrorMessage = "Please provide a valid interest range")]
        public decimal? InterestRate { get; set; }

        public DateTime CreationDateTime { get; set; }

        public DateTime LastModifiedDateTime{ get; set; }

        public string Status { get; set; }
      

    }
}