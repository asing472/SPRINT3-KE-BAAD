﻿//Created by Akash Kumar Singh

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Threading.Tasks;
using Pecunia.Mvc.Models;
using Pecunia.BusinessLayer;
using Pecunia.Entities;
using Pecunia.Mvc.ServiceReference3;

namespace Pecunia.Mvc.Controllers
{
    public class RegularAccountsController : Controller
    {
        // URL: RegularAccounts/Create
        public  ActionResult Create()
        {
            //Creating and initializing viewmodel object 
            RegularAccountViewModel regularAccountViewModel = new RegularAccountViewModel()
            {
               
            };

            //Calling view & passing viewmodel object to view
            return View(regularAccountViewModel);
        }

        // URL: RegularAccounts/Create
        [HttpPost]
        public async Task<ActionResult> Create(RegularAccountViewModel accountVM)
        {
            //Creating object of CustomerBL 
            CustomerBL customerBL = new CustomerBL();

            //Creating object of RegularAccountBL
            RegularAccountBL regularAccountBL = new RegularAccountBL();

            //Creating object of RegularAccount EntityModel
            RegularAccount regularAccount = new RegularAccount();

            bool isCreated = false;

            //Invoking the GetCustomerByCustomerNumberBL method of CustomerBL
            if (await customerBL.GetCustomerByCustomerNumberBL(accountVM.CustomerNumber) != null)
            {
                //Creating object of Customer EntityModel 
                Customer customer = new Customer();

                //Invoking the GetCustomerByCustomerNumberBL method of CustomerBL
                customer = await customerBL.GetCustomerByCustomerNumberBL(accountVM.CustomerNumber);
                Guid custID = customer.CustomerID;
                regularAccount.CustomerID = custID;
                regularAccount.AccountType = accountVM.AccountType;
                regularAccount.Branch = accountVM.Branch;
                regularAccount.MinimumBalance = Convert.ToDecimal(accountVM.MinimumBalance);
                regularAccount.InterestRate = Convert.ToDecimal(accountVM.InterestRate);
                regularAccount.CreationDateTime = Convert.ToDateTime(DateTime.Now);
                regularAccount.LastModifiedDateTime = Convert.ToDateTime(DateTime.Now);
                isCreated = await regularAccountBL.CreateAccountBL(regularAccount);


            }

            if (isCreated)
            {
                //Go to List Action Method of RegularAccounts Controller
                return RedirectToAction("List");

            }

            else
            {
                //Returning plain html text
                return Content("Account not created, customer does not exists");

            }



        }

        public async Task<ActionResult> List()
        {
            //Creating object of RegularAccountBL
            RegularAccountBL regularAccountBL = new RegularAccountBL();

            //Invoking the GetAllAccountsBL method of RegularAccountBL
            List<GetRegularAccountByAccountNo_Result> accounts = await regularAccountBL.GetAllAccountsBL();

            //Creating list of RegularAccount View model
            List<RegularAccountViewModel> accountsVM = new List<RegularAccountViewModel>();

            //Create proxy: used to call the service
            using (Service1Client accountServiceClient = new Service1Client())
            {
               
                //Getting list of Regular Accounts by calling Service
                RegularAccountDataContract[] accountsDC = accountServiceClient.GetAllAccountsDAL();


                //Convert data from DataContract to ViewModel
                accountsVM = accountsDC.Select
                  (
                  item => new RegularAccountViewModel()
                  {

                      CustomerNumber = item.CustomerNumber,
                      CustomerName = item.CustomerName,
                      AccountNo = item.AccountNo,
                      AccountType = item.AccountType,
                      Branch = item.Branch,
                      MinimumBalance = item.MinimumBalance,
                      InterestRate = item.InterestRate,
                      Status = item.Status,
                      CreationDateTime = item.CreationDateTime,
                      LastModifiedDateTime = item.LastModifiedDateTime

                  }
                  ).ToList();
            
                //Calling view & passing viewmodel object to view
                return View(accountsVM);

            }
     

        }


        //URL:RegularAccounts/ApplyEdit
        public ActionResult ApplyEdit()
        {
            //Creating and initializing viewmodel object
            RegularAccountViewModel regularAccountViewModel = new RegularAccountViewModel()
            {

            };

            //Calling and passing view model object to view
            return View(regularAccountViewModel);
        }

        [HttpPost]
        public async Task<ActionResult> ApplyEdit(RegularAccountViewModel accountVM)
        {
            //Creating object of RegularAccountBL
            RegularAccountBL accbl = new RegularAccountBL();

            //Creating object of RegularAccount EntityModel
            RegularAccount acc = new RegularAccount();
            acc.AccountNo = accountVM.AccountNo;

            //Storing Account Number in session
            Session["AccountNo"] = accountVM.AccountNo;

            //Invoking GetAllAccountsBL method of RegularAccountBL
            List<GetRegularAccountByAccountNo_Result> accounts = await accbl.GetAllAccountsBL();
            if(!(accounts.Exists(x => x.AccountNo == accountVM.AccountNo)))
            {
                //Returning plain html text
                return Content("The account does not exists");
            }

            else
            {
                //Invoking GetAccountByAccountNoBL method of RegularAccountBL
                GetRegularAccountByAccountNo_Result account = await accbl.GetAccountByAccountNoBL(acc.AccountNo);

                //Go to AccountDetails Action Method of RegularAccounts Controller
                return RedirectToAction("AccountDetails");
            }
            
        }



        //URL:RegularAccounts/AccountDetails
        public async Task<ActionResult> AccountDetails()
        {
            //Creating object of RegularAccountBL
            RegularAccountBL accbl = new RegularAccountBL();

            //Invoking GetAccountByAccountNoBL method of RegularAccountBL 
            GetRegularAccountByAccountNo_Result account = await accbl.GetAccountByAccountNoBL(Convert.ToString(Session["AccountNo"]));

            //Creating object of RegularAccountViewModel
            RegularAccountViewModel accountVM = new RegularAccountViewModel();
            List<RegularAccountViewModel> ravm = new List<RegularAccountViewModel>();
            accountVM.CustomerNumber = account.CustomerNumber;
            accountVM.CustomerName = account.CustomerName;
            accountVM.AccountNo = account.AccountNo;
            accountVM.AccountType = account.AccountType;
            accountVM.Branch = account.Branch;
            accountVM.MinimumBalance = account.MinimumBalance;
            accountVM.InterestRate = account.InterestRate;
            accountVM.Status = account.Status;
            accountVM.CreationDateTime = account.CreationDateTime;
            accountVM.LastModifiedDateTime = account.LastModifiedDateTime;
           
            ravm.Add(accountVM);

            //Calling and passing view model object to view
            return View(ravm);
        }



        //URL:RegularAccounts/ApplyEdit2
        public  ActionResult ApplyEdit2()
        {
            //Creating and initializing viewmodel object
            RegularAccountViewModel regularAccountViewModel = new RegularAccountViewModel()
            {

            };

         
            //Calling and passing view model object to view
            return View(regularAccountViewModel);
        }

        //URL:RegularAccounts/ApplyEdit2
        [HttpPost]
        public async Task<ActionResult> ApplyEdit2(RegularAccountViewModel accountVM)
        {
            //Creating object of CustomerBL
            CustomerBL cbl = new CustomerBL();

            //Creating object of RegularaccountBL
            RegularAccountBL accbl = new RegularAccountBL();

            //Creating object of RegularAccount EntityModel
            RegularAccount acc = new RegularAccount();

            //Creating object of Customer EntityModel
            Customer cust = new Customer();

            //Storing CustomerNumber in Session
            Session["CustomerNumber"] = accountVM.CustomerNumber;

            //Invoking GetAllCustomersBL method of CustomerBL and storing it in list
            List<Customer> customers = await cbl.GetAllCustomersBL();

            //Checking if the customer exists or not
            if (!(customers.Exists(x => x.CustomerNumber == accountVM.CustomerNumber)))
            {
                //Return plain html text
                return Content("The customer does not exists");
            }

            else
            {
                //Invoking GetCustomerByCustomerNumberBL method of CustomerBL
                cust = await cbl.GetCustomerByCustomerNumberBL(Convert.ToString(Session["CustomerNumber"]));
                Guid custID = cust.CustomerID;

                //Invoking GetAccountsByCustomerIDBL method of CustomerBL
                List<GetRegularAccountsByCustomerID_Result> account = await accbl.GetAccountsByCustomerIDBL(custID);

                if(account != null)
                {
                    //Go to AccountsByCustomer Action Method of RegularAccountViewModel
                    return RedirectToAction("AccountsByCustomer");
                }

                else
                {
                    //Return plain html text
                    return Content("No account exists for the customer");
                }
                
            }
            
        }

        //URL:RegularAccounts/AccountsByCustomer
        public async Task<ActionResult> AccountsByCustomer()
        {
            //Creating object of CustomerBL
            CustomerBL cbl = new CustomerBL();

            //Creating object of RegularAccountBL
            RegularAccountBL accbl = new RegularAccountBL();

            //Creating object of Customer EntityModel
            Customer cust = new Customer();

            string custno = Convert.ToString(Session["CustomerNumber"]);

            //Invoking GetCustomerByCustomerNumberBL method of CustomerBL
            cust = await cbl.GetCustomerByCustomerNumberBL(custno);
            Guid custID = cust.CustomerID;

            //Invoking GetAccountsByCustomerIDBL method of RegularAccountBL
            List<GetRegularAccountsByCustomerID_Result> account = await accbl.GetAccountsByCustomerIDBL(custID);

            //Creating object of RegularAccountViewModel
            List<RegularAccountViewModel> ravm = new List<RegularAccountViewModel>();

            //Storing each item in the above list into RegularAccountViewModel object
            foreach (var item in account)
            {
                RegularAccountViewModel accountVM = new RegularAccountViewModel();
                accountVM.CustomerNumber = item.CustomerNumber;
                accountVM.CustomerName = item.CustomerName;
                accountVM.AccountNo = item.AccountNo;
                accountVM.AccountType = item.AccountType;
                accountVM.Branch = item.Branch;
                accountVM.MinimumBalance = item.MinimumBalance;
                accountVM.InterestRate = item.InterestRate;
                accountVM.Status = item.Status;
                accountVM.CreationDateTime = item.CreationDateTime;
                accountVM.LastModifiedDateTime = item.LastModifiedDateTime;

                ravm.Add(accountVM);
            }

            //Calling and passing view model object to view
            return View(ravm);
        }


        // URL: RegularAccounts/Update
        public async Task<ActionResult> Update()
        {
            RegularAccountBL accbl = new RegularAccountBL();

            //Creating and initializing viewmodel object
            RegularAccountViewModel accountVM = new RegularAccountViewModel();
            accountVM.AccountNo = Convert.ToString(Session["AccountNo"]);

            //Invoking GetAccountByAccountNoBL method of RegularaccountBL
            GetRegularAccountByAccountNo_Result account = await accbl.GetAccountByAccountNoBL(Convert.ToString(Session["AccountNo"]));

            //Populating the view model with values
            string Branch = account.Branch;
            string AccountType = account.AccountType;
            accountVM.Branch = account.Branch;
            accountVM.AccountType = account.AccountType;

            //calling and passing view model object to view
            return View(accountVM);
        }

        // URL: RegularAccounts/Update
        [HttpPost]
        public async Task<ActionResult> Update(RegularAccountViewModel regularAccountVM)
        {
            //Creating object of RegularAccountBL
            RegularAccountBL accBL = new RegularAccountBL();

            //Invoking GetAccountByAccountNoBL of RegularAccountBL 
            GetRegularAccountByAccountNo_Result account = await accBL.GetAccountByAccountNoBL(regularAccountVM.AccountNo);
            
            //Extracting the values from view model
            account.AccountType = regularAccountVM.AccountType;
            account.Branch = regularAccountVM.Branch;
            account.LastModifiedDateTime = Convert.ToDateTime(DateTime.Now);
            
            //Invoking UpdateBranchBL of RegularAccountBL
            bool isUpdatedBranch = await accBL.UpdateBranchBL(account.AccountNo,account.Branch);

            //Invoking UpdateAccountTypeBL of RegularAccountBL
            bool isUpdatedType = await accBL.UpdateAccountTypeBL(account.AccountNo,account.AccountType);

            if (isUpdatedBranch || isUpdatedType)
            {
                //Go to List Action Method of RegularAccounts controller
                return RedirectToAction("List");

            }

            else
            {

                //Return plain html text
                return Content("Account not updated");

            }
        }

        // URL: RegularAccounts/Delete
        [HttpPost]
        public async Task<ActionResult> Delete(RegularAccountViewModel regularAccountVM)
        {
            //Creating object of RegularAccountBL
            RegularAccountBL accBL = new RegularAccountBL();

            //Invoking GetAccountByAccountNoBL method of RegularAccountBL
            GetRegularAccountByAccountNo_Result account = await accBL.GetAccountByAccountNoBL(regularAccountVM.AccountNo);


            account.LastModifiedDateTime = Convert.ToDateTime(DateTime.Now);

            //Invoking DeleteAccountBL method of RegularAccountBL
            bool isDeleted = await accBL.DeleteAccountBL(account.AccountNo);
          

            if (isDeleted)
            {
                //Go to List Action Method of RegularAccounts controller
                return RedirectToAction("List");

            }

            else
            {
                //Return plain html text
                return Content("Account not deleted");

            }

        }
    }
}