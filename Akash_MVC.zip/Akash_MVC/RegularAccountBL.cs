﻿//Created by Akash Kumar Singh

using Pecunia.Entities;
using Pecunia.Contracts.BLContracts;
using Pecunia.Contracts.DALContracts;
using Pecunia.DataAcessLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pecunia.Exceptions;
using Pecunia.Helpers;
using System.Text.RegularExpressions;

namespace Pecunia.BusinessLayer
{
    /// <summary>
    /// Contains data access layer methods for creating, updating, deleting accounts from RegularAccount collection.
    /// </summary>
    public class RegularAccountBL : BLBase<RegularAccount>, IRegularAccountBL, IDisposable
    {
        //fields
        RegularAccountDALBase regaccountDAL;

        /// <summary>
        /// Constructor.
        /// </summary>
        public RegularAccountBL()
        {
            this.regaccountDAL = new RegularAccountDAL();
        }

        /// <summary>
        /// Validations on data before adding.
        /// </summary>
        /// <param name="entityObject">Represents object to be validated.</param>
        /// <returns>Returns a boolean value, that indicates whether the data is valid or not.</returns>

        protected async override Task<bool> Validate(RegularAccount entityObject)
        {
            //CustomerBL cbl = new CustomerBL();

            //Create string builder
            StringBuilder sb = new StringBuilder();
            bool valid = await base.Validate(entityObject);

            Guid custID = entityObject.CustomerID;
           
            //Branch should be in (Mumbai,Bengaluru,Delhi,Chennai) 
            if (!(entityObject.Branch.Equals("Mumbai", StringComparison.OrdinalIgnoreCase)) && !(entityObject.Branch.Equals("Bengaluru", StringComparison.OrdinalIgnoreCase))
                && !(entityObject.Branch.Equals("Delhi", StringComparison.OrdinalIgnoreCase)) && !(entityObject.Branch.Equals("Chennai", StringComparison.OrdinalIgnoreCase)))
            {
                valid = false;
                sb.Append(Environment.NewLine + "Branch should be one among Mumbai, Chennai, Delhi or Bengaluru");
            }

            //Account Type should be Savings or Current 
            if (!(entityObject.AccountType.Equals("Savings", StringComparison.OrdinalIgnoreCase)) && !(entityObject.AccountType.Equals("Current", StringComparison.OrdinalIgnoreCase)))
            {
                valid = false;
                sb.Append(Environment.NewLine + "Account Type not valid");
            }

            //Account type can't be null
            if (!(entityObject.AccountType != "") && !(entityObject.AccountType != null))
            {
                valid = false;
                sb.Append(Environment.NewLine + "AccountType can't be blank");
            }

            //Branch can't be null
            if (!(entityObject.Branch != "") && !(entityObject.Branch != null))
            {
                valid = false;
                sb.Append(Environment.NewLine + "Branch can't be blank");
            }

            if (valid == false)
                throw new PecuniaException(sb.ToString());
            return valid;

        }


        /// <summary>
        /// Adds new account to Regular Accounts collection.
        /// </summary>
        /// <param name="newAccount">Contains the account details to be added.</param>
        /// <returns>Determinates whether the new regular account is added.</returns>
        public async Task<bool> CreateAccountBL(RegularAccount newAccount)
        {
            bool AccountCreated = false;
            //string AccountNo="";
            try
            {
                if (await Validate(newAccount))
                {
                    await Task.Run(() =>
                    {

                        AccountCreated = regaccountDAL.CreateAccountDAL(newAccount);

                        AccountCreated = true;
                        
                    });
                }
            }
            catch (Exception)
            {
                throw;
            }

            return AccountCreated;
        }

        /// <summary>
        /// Gets all accounts from the RegularAccount collection.
        /// </summary>
        /// <returns>Returns list of all regular accounts.</returns>
        public async Task<List<GetRegularAccountByAccountNo_Result>> GetAllAccountsBL()
        {
            List<GetRegularAccountByAccountNo_Result> regaccountList = null;
            try
            {
                await Task.Run(() =>
                {
                    regaccountList = regaccountDAL.GetAllAccountsDAL();
                });

            }
            catch (Exception)
            {
                throw;
            }
            return regaccountList;
        }

        /// <summary>
        /// Gets regular account based on AccountNo
        /// </summary>
        /// <param name="searchAccountNo">Contains the account no to search the account.</param>
        /// <returns>returns the object of Regular Account Class.</returns>
        public async Task<GetRegularAccountByAccountNo_Result> GetAccountByAccountNoBL(string searchAccountNo)
        {
            GetRegularAccountByAccountNo_Result searchAccount = null;
            try
            {
                await Task.Run(() =>
                {
                    searchAccount = regaccountDAL.GetAccountByAccountNoDAL(searchAccountNo);
                });

            }
            catch (Exception)
            {
                throw;
            }
            
            return searchAccount;

        }


        /// <summary>
        /// Gets list of regular accounts based on Customer
        /// </summary>
        /// <param name="searchCustomerID">Contains the Customer ID to search the accounts.</param>
        /// <returns>Returns the list of Regular Account class objects where the Customer ID matches.</returns>
        public async Task<List<GetRegularAccountsByCustomerID_Result>> GetAccountsByCustomerIDBL(Guid searchCustomerID)
        {

            List<GetRegularAccountsByCustomerID_Result> AccountsByCustNo = null;
            try
            {
                await Task.Run(() =>
                {
                    AccountsByCustNo = regaccountDAL.GetAccountsByCustomerIDDAL(searchCustomerID);
                });


            }
            catch (Exception)
            {
                throw;
            }
            return AccountsByCustNo;

        }


        /// <summary>
        /// Gets list of regular accounts based on Account Type
        /// </summary>
        /// <param name="searchAccountType">Contains the type of account(Savings or Current) to search the accounts.</param>
        /// <returns>Returns the list of Regular Account class objects.</returns>
        public async Task<List<GetRegularAccountsByAccountType_Result>> GetAccountsByTypeBL(string searchAccountType)
        {

            List<GetRegularAccountsByAccountType_Result> AccountsByType = null;
            try
            {
                await Task.Run(() =>
                {
                    AccountsByType = regaccountDAL.GetAccountsByTypeDAL(searchAccountType);
                });

            }

            catch (Exception ex)
            {
                throw ex;
            }
            return AccountsByType;

        }

        /// <summary>
        /// Gets list of regular accounts based on branch
        /// </summary>
        /// <param name="searchBranch">Contains the regular account in a particular branch.</param>
        /// <returns>Returns the list of RegularAccount class objects.</returns>
        public async Task<List<GetRegularAccountsByBranch_Result>> GetAccountsByBranchBL(string searchBranch)
        {

            List<GetRegularAccountsByBranch_Result> AccountsByBranch = null;
            try
            {
                await Task.Run(() =>
                {
                    AccountsByBranch = regaccountDAL.GetAccountsByBranchDAL(searchBranch);
                });

            }

            catch (Exception ex)
            {
                throw ex;
            }
            return AccountsByBranch;

        }

        /// <summary>
        /// Gets list of regular accounts based on range of dates
        /// </summary>
        /// <param name="startDate">Contains the starting date.</param>
        /// <param name="endDate">Contains the ending date.</param>
        /// <returns>Returns the list of Regular Account class objects.</returns>
        public async Task<List<GetRegularAccountsByAccountOpeningDate_Result>> GetAccountsByAccountOpeningDateBL(DateTime startDate, DateTime endDate)
        {

            List<GetRegularAccountsByAccountOpeningDate_Result> AccountsByDate = null;
            try
            {
                await Task.Run(() =>
                {
                    AccountsByDate = regaccountDAL.GetAccountsByAccountOpeningDateDAL(startDate, endDate);
                });

            }

            catch (Exception)
            {
                throw;
            }
            return AccountsByDate;

        }

        /// <summary>
        /// Gets Current Balance in the regular account
        /// </summary>
        /// <param name="accountNumber">Contains the account number for which balance is requested.</param>
        /// <returns>Returns the current balance.</returns>
        public async Task<double> GetBalanceBL(string accountNumber)
        {

            double balance = 0;
            try
            {
                await Task.Run(() =>
                {
                    balance = regaccountDAL.GetBalanceDAL(accountNumber);
                });
            }
            catch (Exception)
            {
                throw;
            }
            return balance;

        }

        /// <summary>
        /// Updates the balance after every transaction
        /// </summary>
        /// <param name="accountNumber">Contains the account number.</param>
        /// <param name="balance">Contains the updated balance after a transaction .</param>
        /// <returns>Determines whether the account balance is updated or not.</returns>
        public async Task<bool> UpdateBalanceBL(string accountNumber, double balance)
        {

            bool BalanceUpdated = false;

            try
            {
                if (await GetAccountByAccountNoBL(accountNumber) != null)
                {
                    regaccountDAL.UpdateBalanceDAL(accountNumber, balance);
                    BalanceUpdated = true;
                   
                }
            }
            catch (Exception)
            {
                throw;
            }

            return BalanceUpdated;
        }

        /// <summary>
        /// Updates the branch of a regular account
        /// </summary>
        /// <param name="accountNumber">Contains the account number of the account.</param>
        /// <param name="Branch">Contains the new branch</param>
        /// <returns>Determines whether the branch is updated or not.</returns>
        public async Task<bool> UpdateBranchBL(string accountNumber, string Branch)
        {
            bool AccountBranchUpdated = false;
            try
            {

                if ((await GetAccountByAccountNoBL(accountNumber) != null))
                {

                    this.regaccountDAL.UpdateBranchDAL(accountNumber, Branch);
                    AccountBranchUpdated = true;
                    

                }

            }
            catch (Exception)
            {
                throw;
            }

            return AccountBranchUpdated;
        }

        /// <summary>
        /// Updates the account type from savings to current or vice-versa
        /// </summary>
        /// <param name="accountNumber">Contains the account number of the account.</param>
        /// <param name="accountType">Contains the new account type of the account.</param>
        /// <returns>Determines whether the account type is updated or not.</returns>
        public async Task<bool> UpdateAccountTypeBL(string accountNumber, string accType)
        {
            bool AccountTypeUpdated = false;
            try
            {

                if ((await GetAccountByAccountNoBL(accountNumber) != null))
                {

                    this.regaccountDAL.UpdateAccountTypeDAL(accountNumber, accType);
                    AccountTypeUpdated = true;
                   

                }

            }
            catch (Exception)
            {
                throw;
            }

            return AccountTypeUpdated;
        }

        /// <summary>
        /// Deletes an existing regular account
        /// </summary>
        /// <param name="deleteAccountNo">Contains the account number of the account to be deleted.</param>
        /// <returns>Determines whether the account is deleted or not.</returns>
        public async Task<bool> DeleteAccountBL(string deleteAccountNo)
        {
            bool AccountDeleted = false;
            try
            {


                if (await GetAccountByAccountNoBL(deleteAccountNo) != null)
                {
                    this.regaccountDAL.DeleteAccountDAL(deleteAccountNo);
                    AccountDeleted = true;
                   
                }

            }

            catch (Exception)
            {
                throw;
            }

            return AccountDeleted;
        }

        /// <summary>
        /// Disposes DAL object(s).
        /// </summary>
        public void Dispose()
        {
            ((RegularAccountDAL)regaccountDAL).Dispose();
        }
    }

}

