﻿//Created by Akash Kumar Singh


using Pecunia.Entities;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Pecunia.Contracts.BLContracts
{

    public interface IRegularAccountBL : IDisposable
    {
        Task<bool> CreateAccountBL(RegularAccount newAccount);
        Task<List<GetRegularAccountByAccountNo_Result>> GetAllAccountsBL();
        Task<GetRegularAccountByAccountNo_Result> GetAccountByAccountNoBL(string searchAccountNo);
        Task<List<GetRegularAccountsByCustomerID_Result>> GetAccountsByCustomerIDBL(Guid searchCustomerID);
        Task<List<GetRegularAccountsByAccountType_Result>> GetAccountsByTypeBL(string searchAccountType);
        Task<List<GetRegularAccountsByBranch_Result>> GetAccountsByBranchBL(string searchBranch);
        Task<List<GetRegularAccountsByAccountOpeningDate_Result>> GetAccountsByAccountOpeningDateBL(DateTime startDate, DateTime endDate);
        Task<double> GetBalanceBL(string accountNumber);
        Task<bool> UpdateBalanceBL(string accountNumber, double balance);
        Task<bool> UpdateBranchBL(string accountNumber, string Branch);
        Task<bool> UpdateAccountTypeBL(string accountNumber, string accType);
        Task<bool> DeleteAccountBL(string deleteAccountNo);
    }
}
