﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Pecunia.Entities;
using Pecunia.BusinessLayer;
using Pecunia.Contracts.BLContracts;
using Pecunia.Helpers;


namespace Capgemini.Pecunia.WPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class AccountsWindow : Window
    {
        public AccountsWindow()
        {
            InitializeComponent();
        }

        RegularAccountBL regularAccountBL = new RegularAccountBL();
        FixedAccountBL fixedAccountBL = new FixedAccountBL();
        CustomerBL customerBL = new CustomerBL();
        List<GetRegularAccountByAccountNo_Result> regaccounts = new List<GetRegularAccountByAccountNo_Result>();
        List<GetAllFixedAccounts_Result> fixaccounts = new List<GetAllFixedAccounts_Result>();


        private async void Window_Loaded(object sender, RoutedEventArgs e)
        {
            var regaccounts = await regularAccountBL.GetAllAccountsBL();
            resultgrid.ItemsSource = regaccounts;

            var fixaccounts = await fixedAccountBL.GetAllAccountsBL();
            resultgrid2.ItemsSource = fixaccounts;
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void ComboBoxItem_Selected(object sender, RoutedEventArgs e)
        {

        }



        private async void BtnCreate_Click(object sender, RoutedEventArgs e)
        {
            if((Convert.ToDecimal(txtMin.Text) < 0)|| (Convert.ToDecimal(txtMin.Text) < 0))
            {
                if (Convert.ToDecimal(txtMin.Text) < 0)
                {
                    MessageBox.Show("Invalid minimum balance");
                }

                if (Convert.ToDecimal(txtMin.Text) < 0)
                {
                    MessageBox.Show("Invalid Interest Rate");
                }
            }
           else
            {
                bool accountCreated = false;
                Customer customer = await customerBL.GetCustomerByCustomerNumberBL(txtCustNo.Text);
                if (customer != null)
                {

                    RegularAccount newAcct = new RegularAccount();
                    newAcct.CustomerID = customer.CustomerID;
                    newAcct.AccountType = cmbaccType.Text;
                    newAcct.Branch = cmbBranch.Text;
                    newAcct.MinimumBalance = Convert.ToDecimal(txtMin.Text);
                    newAcct.InterestRate = Convert.ToDecimal(txtInt.Text);

                    accountCreated = await regularAccountBL.CreateAccountBL(newAcct);

                    if (accountCreated == true)
                    {
                        lblTest.Content = newAcct.AccountType + " account created, the account number generated is" + newAcct.AccountNo;
                    }
                }

                else
                {
                    lblTest.Content = "The Customer Number is invalid";
                }
            }
            
        }

        private async void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            string searchType = cmbSearch.Text;
            if (cmbSearch.Text.Equals("Account No"))
            {
                List<GetRegularAccountByAccountNo_Result> regaccounts = await regularAccountBL.GetAllAccountsBL();

                if ((txtSearch.Text).Length != 10)
                {
                    MessageBox.Show("Invalid Account Number");

                }

                else if (!(regaccounts.Exists(x => x.AccountNo == txtSearch.Text)))
                {
                    MessageBox.Show("The account does not exists.");
                }

                else
                {
                    List<GetRegularAccountByAccountNo_Result> emptylist = new List<GetRegularAccountByAccountNo_Result>();

                    var account = await regularAccountBL.GetAccountByAccountNoBL(txtSearch.Text);
                    if (account != null)
                    {
                        List<GetRegularAccountByAccountNo_Result> listacc = new List<GetRegularAccountByAccountNo_Result>();
                        listacc.Add(account);
                        //resultgrid.ItemsSource = emptylist;
                        resultgrid.ItemsSource = listacc;
                    }
                }

            }

            if (cmbSearch.Text.Equals("Customer No"))
            {
                string custno = txtSearch.Text;
                var customer = await customerBL.GetCustomerByCustomerNumberBL(custno);
                if (customer != null)
                {
                    var account = await regularAccountBL.GetAccountsByCustomerIDBL(customer.CustomerID);
                    resultgrid.ItemsSource = account;
                }

            }
            if (cmbSearch.Text.Equals("Account Type"))
            {


                var typeaccount = await regularAccountBL.GetAccountsByTypeBL(cmbsearchaccType.Text);
                resultgrid.ItemsSource = typeaccount;


            }
            if (cmbSearch.Text.Equals("Branch"))
            {

                var branchaccount = await regularAccountBL.GetAccountsByBranchBL(cmbsearchBranch.Text);
                resultgrid.ItemsSource = branchaccount;


            }
            if (cmbSearch.Text.Equals("Date"))
            {

                var dateaccount = await regularAccountBL.GetAccountsByAccountOpeningDateBL(Convert.ToDateTime(date1.SelectedDate), Convert.ToDateTime(date2.SelectedDate));
                resultgrid.ItemsSource = dateaccount;


            }
            clear();


        }

        private async void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show("Do you really wan't to delete this account?", "Alert", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
            {
                int rowindex = resultgrid.SelectedIndex;
                if (rowindex < 0)
                {
                    return;
                }
                RegularAccount regaccount = new RegularAccount();
                regaccount.AccountNo = getCellData(resultgrid, rowindex, 4);

                regaccount.Status = "Closed";

                bool isDeleted = await regularAccountBL.DeleteAccountBL(regaccount.AccountNo);

                if (isDeleted)
                {
                    lblTest.Content = "Account deleted";
                }
            }
        }

        private async void ButUpdate_Click(object sender, RoutedEventArgs e)
        {
            int rowindex = resultgrid.SelectedIndex;
            if (rowindex < 0)
            {
                return;
            }
            RegularAccount regaccount = new RegularAccount();
            regaccount.AccountNo = getCellData(resultgrid, rowindex, 4);

            regaccount.Branch = cmbBranch.Text;
            regaccount.AccountType = cmbaccType.Text;
            bool isUpdatedBranch = await regularAccountBL.UpdateBranchBL(regaccount.AccountNo, regaccount.Branch);
            bool isUpdatedType = await regularAccountBL.UpdateAccountTypeBL(regaccount.AccountNo, regaccount.AccountType);

            if (isUpdatedBranch || isUpdatedType)
            {
                lblTest.Content = "Account updated";
            }
        }

        private void TextBox_TextChanged_1(object sender, TextChangedEventArgs e)
        {

        }

        private void CmbSearch_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void Resultgrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int rowindex = resultgrid.SelectedIndex;
            if (rowindex < 0)
            {
                return;
            }
            txtCustNo.Text = getCellData(resultgrid, rowindex, 1);
            cmbaccType.Text = getCellData(resultgrid, rowindex, 6);
            cmbBranch.Text = getCellData(resultgrid, rowindex, 7);
            txtInt.Text = getCellData(resultgrid, rowindex, 9);
            txtMin.Text = getCellData(resultgrid, rowindex, 8);

        }

        private string getCellData(DataGrid dgv, int rowindex, int cellindex)
        {
            DataGridRow drow =
                dgv.ItemContainerGenerator.ContainerFromIndex(rowindex) as DataGridRow;
            var cellContent =
                dgv.Columns[cellindex].GetCellContent(drow) as TextBlock;
            return cellContent.Text;
        }


        private void TxtSearch_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void Resultgrid_SelectionChanged_1(object sender, SelectionChangedEventArgs e)
        {

        }

        private async void BtnRefresh_Click(object sender, RoutedEventArgs e)
        {
            var regaccounts = await regularAccountBL.GetAllAccountsBL();
            resultgrid.ItemsSource = regaccounts;
            clear();
        }

        private void clear()
        {
            txtCustNo.Text = "";
            cmbaccType.Text = "";
            cmbBranch.Text = "";
            txtInt.Text = "";
            txtMin.Text = "";
            txtCustNo2.Text = "";
            cmbBranch2.Text = "";
            txtInt2.Text = "";
            txtMin2.Text = "";
            txtTenure.Text = "";
            txtAmt.Text = "";
            //txtSearch.Text = "";
            //cmbSearch.Text = "";
            //cmbsearchaccType.Text = "";
            //cmbsearchBranch.Text = "";
            lblTest.Content = "";
            lblTest2.Content = "";

        }

        private void CmbBranch_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void CmbaccType_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

        }

        private void DataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void TextBox_TextChanged_2(object sender, TextChangedEventArgs e)
        {

        }

        private void BtnHome_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            EmployeeWindow showWindow = new EmployeeWindow();
            showWindow.Show();

        }

        private async void BtnCreate2_Click(object sender, RoutedEventArgs e)
        {
            bool accountCreated = false;
            Customer customer2 = await customerBL.GetCustomerByCustomerNumberBL(txtCustNo2.Text);
            if (customer2 != null)
            {
                FixedAccount newAcct = new FixedAccount();
                newAcct.CustomerID = customer2.CustomerID;
                newAcct.Branch = cmbBranch2.Text;
                newAcct.MinimumBalance = Convert.ToDecimal(txtMin2.Text);
                newAcct.InterestRate = Convert.ToDecimal(txtInt2.Text);
                newAcct.Tenure = Convert.ToDecimal(txtTenure.Text);
                newAcct.FDDeposit = Convert.ToDecimal(txtAmt.Text);

                accountCreated = await fixedAccountBL.CreateAccountBL(newAcct);

                if (accountCreated == true)
                {
                    lblTest.Content = "Fixed account created, the account number generated is" + newAcct.AccountNo;
                }
            }

            else
            {
                lblTest.Content = "The Customer Number is invalid";
            }
        }

        private void BtnUpdate2_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnDelete2_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnSearch2_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnHome2_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            EmployeeWindow showWindow = new EmployeeWindow();
            showWindow.Show();
        }

        private void Resultgrid2_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
