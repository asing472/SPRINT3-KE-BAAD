﻿////Created by Akash Kumar Singh

using Pecunia.Entities;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Pecunia.Contracts.BLContracts
{
    public interface IFixedAccountBL : IDisposable
    {
        Task<bool> CreateAccountBL(FixedAccount newfixed);
        Task<List<GetAllFixedAccounts_Result>> GetAllAccountsBL();
        Task<GetFixedAccountByAccountNo_Result> GetAccountByAccountNoBL(string searchAccountNo);
        Task<List<GetFixedAccountsByCustomerID_Result>> GetAccountsByCustomerIDBL(Guid searchCustomerID);
        Task<List<GetFixedAccountsByBranch_Result>> GetAccountsByBranchBL(string searchBranch);
        Task<List<GetFixedAccountsByAccountOpeningDate_Result>> GetAccountsByAccountOpeningDateBL(DateTime startDate, DateTime endDate);
        Task<double> GetBalanceBL(string accountNumber);
        Task<bool> UpdateBalanceBL(string accountNumber, double balance);
        Task<bool> UpdateBranchBL(string accountNumber, string Branch);
        Task<bool> DeleteAccountBL(string deleteAccountNo);
    }
}
