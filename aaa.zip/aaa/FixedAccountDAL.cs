﻿//Created by Akash Kumar Singh

using Pecunia.Entities;
using Pecunia.Contracts.DALContracts;
using Pecunia.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data;
using System.Data.Entity.Core.Objects;

namespace Pecunia.DataAcessLayer
{
    /// <summary>
    /// Contains data access layer methods for creating, updating, deleting account from Fixed Accounts collection.
    /// </summary>
    public class FixedAccountDAL : FixedAccountDALBase, IDisposable
    {

        /// <summary>
        /// Adds new account to Fixed Accounts collection.
        /// </summary>
        /// <param name="newAccount">Contains the account details to be added.</param>
        /// <returns>Determinates whether the new account is added.</returns>
        public override bool CreateAccountDAL(FixedAccount newAccount)
        {
            using (TeamEEntities db = new TeamEEntities())
            {
                ObjectResult<CreateFixedAccount_Result> CreateFixedAccount = db.CreateFixedAccount(newAccount.CustomerID, newAccount.Branch, newAccount.Tenure, newAccount.FDDeposit, newAccount.MinimumBalance, newAccount.InterestRate);
                var result = CreateFixedAccount.FirstOrDefault();

                int v = result.Column1;
                newAccount.AccountNo = result.Column2;
            }

            return true;
        }

        /// <summary>
        /// Gets all regular accounts from the collection.
        /// </summary>
        /// <returns>Returns list of all accounts.</returns>
        public override List<GetAllFixedAccounts_Result> GetAllAccountsDAL()
        {

            using (TeamEEntities db = new TeamEEntities())
            {
                List<GetAllFixedAccounts_Result> AllFixedAccounts = db.GetAllFixedAccounts().ToList();
                //List<RegularAccount> AllRegularAccounts = (from a in db.RegularAccounts select a).ToList();

                return AllFixedAccounts;
            }



        }



        /// <summary>
        /// Gets regular account based on AccountNo
        /// </summary>
        /// <param name="searchAccountNo">Contains the account no to search the account.</param>
        /// <returns>returns the object of RegularAccount Class.</returns>
        public override GetFixedAccountByAccountNo_Result GetAccountByAccountNoDAL(string searchAccountNo)
        {

            //existingAccount = new RegularAccount();

            using (TeamEEntities db = new TeamEEntities())
            {
                GetFixedAccountByAccountNo_Result existingAccount = db.GetFixedAccountByAccountNo(searchAccountNo).FirstOrDefault();
                return existingAccount;

            }



        }


        /// <summary>
        /// Gets list of regular accounts based on CustomerID
        /// </summary>
        /// <param name="searchCustomerID">Contains the Customer ID to search the accounts.</param>
        /// <returns>Returns the list of RegularAccount class objects where the Customer ID matches.</returns>
        public override List<GetFixedAccountsByCustomerID_Result> GetAccountsByCustomerIDDAL(Guid searchCustomerID)
        {

            using (TeamEEntities db = new TeamEEntities())
            {

                List<GetFixedAccountsByCustomerID_Result> FixedAccountsByCustomerID = db.GetFixedAccountsByCustomerID(searchCustomerID).ToList();

                return FixedAccountsByCustomerID;
            }

        }

        

        /// <summary>
        /// Gets list of regular accounts based on branch
        /// </summary>
        /// <param name="searchBranch">Contains the account in a particular branch.</param>
        /// <returns>Returns the list of Fixed Account class objects.</returns>
        public override List<GetFixedAccountsByBranch_Result> GetAccountsByBranchDAL(string searchBranch)
        {
            using (TeamEEntities db = new TeamEEntities())
            {

                List<GetFixedAccountsByBranch_Result> AccountsByBranch = db.GetFixedAccountsByBranch(searchBranch).ToList();

                return AccountsByBranch;
            }
        }

        /// <summary>
        /// Gets list of regular accounts based on range of dates
        /// </summary>
        /// <param name="startDate">Contains the starting date.</param>
        /// <param name="endDate">Contains the ending date.</param>
        /// <returns>Returns the list of FixedAccount class objects.</returns>
        public override List<GetFixedAccountsByAccountOpeningDate_Result> GetAccountsByAccountOpeningDateDAL(DateTime startDate, DateTime endDate)
        {

            using (TeamEEntities db = new TeamEEntities())
            {

                List<GetFixedAccountsByAccountOpeningDate_Result> AccountsByDate = db.GetFixedAccountsByAccountOpeningDate(startDate, endDate).ToList();

                return AccountsByDate;
            }

        }

        /// <summary>
        /// Gets Current Balance in the  regular account
        /// </summary>
        /// <param name="accountNumber">Contains the account number for which balance is requested.</param>
        /// <returns>Returns the current balance.</returns>
        public override double GetBalanceDAL(string accountNumber)
        {

            double balance = 0;


            return balance;
        }

        /// <summary>
        /// Updates the balance after every transaction
        /// </summary>
        /// <param name="accountNumber">Contains the account number.</param>
        /// <param name="balance">Contains the updated balance after a transaction .</param>
        /// <returns>Determines whether the account balance is updated or not.</returns>
        public override bool UpdateBalanceDAL(string accountNumber, double balance)
        {
            bool BalanceUpdated = false;


            return BalanceUpdated;
        }

        /// <summary>
        /// Updates the branch of a regular account
        /// </summary>
        /// <param name="accountNumber">Contains the account number of the account.</param>
        /// <returns>Determines whether the branch is updated or not.</returns>
        public override bool UpdateBranchDAL(string accountNumber, string Branch)
        {
            bool AccountBranchUpdated = false;
            using (TeamEEntities db = new TeamEEntities())
            {
                GetFixedAccountByAccountNo_Result account = GetAccountByAccountNoDAL(accountNumber);

                if (account != null)
                {
                    account.Branch = Branch;

                    int n = db.ChangeFixedAccountBranch(account.AccountNo, account.Branch);

                    AccountBranchUpdated = true;
                }


            }

            return AccountBranchUpdated;
        }

       
        /// <summary>
        /// Deletes an existing regular account
        /// </summary>
        /// <param name="deleteAccountNo">Contains the account number of the account to be deleted.</param>
        /// <returns>Determines whether the account is deleted or not.</returns>
        public override bool DeleteAccountDAL(string deleteAccountNo)
        {
            bool AccountDeleted = false;
            using (TeamEEntities db = new TeamEEntities())
            {
                GetFixedAccountByAccountNo_Result account = GetAccountByAccountNoDAL(deleteAccountNo);

                if (account != null)
                {

                    int n = db.DeleteFixedAccount(deleteAccountNo);

                    AccountDeleted = true;
                }


            }


            return AccountDeleted;

        }


        /// <summary>
        /// Clears unmanaged resources such as db connections or file streams.
        /// </summary>

        public void Dispose()
        {
            //No unmanaged resources currently
        }
    }
}