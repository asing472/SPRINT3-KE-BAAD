﻿//Created by Akash Kumar Singh

using Pecunia.Entities;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;

namespace Pecunia.Contracts.DALContracts
{
    public abstract class FixedAccountDALBase
    {
        //Collection of Fixed Accounts
        public static List<FixedAccount> fixedAccountList = new List<FixedAccount>();
       
        //Method for CRUD operations
        public abstract bool CreateAccountDAL(FixedAccount newFixed);
        public abstract List<GetAllFixedAccounts_Result> GetAllAccountsDAL();
        public abstract GetFixedAccountByAccountNo_Result GetAccountByAccountNoDAL(string searchAccountNo);
        public abstract List<GetFixedAccountsByCustomerID_Result> GetAccountsByCustomerIDDAL(Guid searchCustomerID);
        public abstract List<GetFixedAccountsByBranch_Result> GetAccountsByBranchDAL(string searchBranch);
        public abstract List<GetFixedAccountsByAccountOpeningDate_Result> GetAccountsByAccountOpeningDateDAL(DateTime startDate, DateTime endDate);
        public abstract double GetBalanceDAL(string accountNumber);
        public abstract bool UpdateBalanceDAL(string accountNumber, double balance);
        public abstract bool UpdateBranchDAL(string accountNumber, string Branch);
        public abstract bool DeleteAccountDAL(string deleteAccountNo);

        
        /// <summary>
        /// Static Constructor.
        /// </summary>
        static FixedAccountDALBase()
        {
          
        }
    }

}
